<?php

//Inclusion des paramètres de connexion 

require ("config.php");

//Connexion PDO

function getPDOConnection()
{
    // Construction du Data Source Name
    $dsn = 'mysql:dbname=immobilier;host=localhost';

    // Tableau d'options pour la connexion PDO
    $options = [
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ];

    // Création de la connexion PDO 
    $pdo = new PDO('mysql:host=localhost;dbname=immobilier;chartset=utf8', 'root','root');
    $pdo->exec('SET NAMES UTF8');

    return $pdo;
}

/**
 * Prépare et exécute une requête SQL
 */
function prepareAndExecuteQuery(string $sql, array $criteria = []): PDOStatement
{
    // Connexion PDO
    $pdo = getPDOConnection();

    // Préparation de la requête SQL
    $query = $pdo->prepare($sql);

    // Exécution de la requête
    $query->execute($criteria);

    // Retour du résultat
    return $query;


 // Enregistrement du formulaire

 function formulaire(int $id_logement, string $titre, string $adresse, string $ville, string $codepostal, string $surface, string $prix, string $photo, string $type, string $description)
{
    initFormulaire();

    $logement['id_logement'] = [
        'id_logement' => $id_logement,
        'titre' => $titre,
        'adresse' => $adresse,
        'ville' => $ville,
        'codepostal' => $codepostal,
        'surface' => $surface,
        'prix' => $prix,
        'photo' => $photo,
        'type' => $type,
        'description' => $description];
}

// Avoir uniquement des nombres entier pour le prix et la surface

function Arrondi()
{

    $sql = SELECT ROUND($prix,$surface)
    FROM ('logement');
}


// Avoir le prix en euro au format français
 
function format_price(float $prix)
{
    
    $formatter = new NumberFormatter('fr_FR', NumberFormatter::CURRENCY);

    return $formatter->formatCurrency($prix, 'EUR');
}

// Afficher les logements par ordre d'id 

if($dsn=getPDOConnection("immobilier","logement"))
{
    $requete="SELECT $ FROM logement ORDER BY id_logement";
    $result=$dsn->query($requete);
 
}
