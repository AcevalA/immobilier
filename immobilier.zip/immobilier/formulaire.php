<?php

// Inclusion des fonctions

require ("functions.php");

// écriture dans le taleau des données du formulaire 

if (!empty($_POST['titre'])&& !empty($_POST['adresse'])&& !empty($_POST['ville'])&& !empty($_POST['codepostal'])&& !empty($_POST['surface'])&& !empty($_POST['prix'])&& !empty($_POST['photo'])&& !empty($_POST['type'])&& !empty($_POST['description'])) 
{
$id_logement="\N";
$titre=$dsn-->quote($_POST['titre']);
$adresse=$dsn-->quote($_POST['adresse']);
$ville=$dsn-->quote($_POST['ville']);
$codepostal=$dsn-->quote($_POST['codepostal']);
$surface=$dsn-->quote($_POST['surface']);
$prix=$dsn-->quote($_POST['prix']);
$photo=$dsn-->quote($_POST['photo']);
$type=$dsn-->quote($_POST['type']);
$description=$dsn-->quote($_POST['description']);

}




// Inclusion de l'affichage

include ("formulaire.phtml");

